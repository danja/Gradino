making your own skins.

Do not change the default skin.

Add a new folder to the skins directory, the folder name is your new skin's name.
Copy any of the skin bitmaps you want to change to your new directory. Each bitmap has a text file with the same name.  It describes the skin.
The mask file is optional, it contains transparency information.  A simpler way to use transparency is the keyword 'transparent_pixel x,y' in the text file. This tells synthedit which pixel contains the 'transparent' color.
Then use a paint program to edit each of the bitmap files.  Keep your new skins the same
size as the originals, this will allow you to change skins without having to rearrange
all your controls.  You may need to restart synthedit to see your changes.

Font face, size and color are controlled by the file global.txt.


